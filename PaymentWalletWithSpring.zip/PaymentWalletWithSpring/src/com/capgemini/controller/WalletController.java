package com.capgemini.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.service.WalletService;

@Controller
public class WalletController {
	int acn;
	@Autowired
	  WalletService service=null;

	public WalletService getService() {
		return service;
	}

	public void setService(WalletService service) {
		this.service = service;
	}
	
	Customer cus= new Customer();
/*************************************Login***********************************************/
@RequestMapping(value="/HomePage",method=RequestMethod.GET)
public String displayHomePage(Model model) {
	model.addAttribute("login", cus);
	return "HomeLoginPage";
}

@RequestMapping(value="/LoginValidator",method=RequestMethod.POST)
public String displayLoginValidator(@ModelAttribute("login")Customer cus1 ,Model model) {
	
	
		cus=service.getCustomer(cus1.getAccountNo());
		if(cus==null) {
			model.addAttribute("errorMsg", "Account does not exist");
			return "HomeLoginPage";
		}
		else if (cus.getPassword().equals(cus1.getPassword())) {
			acn=cus1.getAccountNo();
			Customer cus3=service.getCustomer(cus1.getAccountNo());
			model.addAttribute("acc", cus1.getAccountNo());
			model.addAttribute("name", cus3.getName());
			model.addAttribute("date", LocalDate.now());
			return "AllFunctionPage";
		}
		else
		model.addAttribute("errorPwd", "Wrong Password");
		return "HomeLoginPage";
		
}	
/************************************Create Account*************************************************/
@RequestMapping(value="/Registration")
public String displayRegistrationPage(Model model) {
	Customer cus1=new Customer();
	model.addAttribute("reg", cus1);
	return "RegistrationPage";
}

@RequestMapping(value="/InsertData")
public String insertData(@ModelAttribute("reg") @Valid Customer cus,BindingResult result,Model model) {
	
	if(result.hasErrors()) {
		return "RegistrationPage";
	}else {
	
	Random rand = new Random();
	int a = rand.nextInt(90000)+10000;
	cus.setAccountNo(a);
	Customer cus1=service.createAccount(cus);
	model.addAttribute("name", cus1.getName());
	model.addAttribute("email", cus1.getEmailID());
	model.addAttribute("ph", cus1.getPhoneNo());
	model.addAttribute("account", cus1.getAccountNo());
	model.addAttribute("bal", cus1.getBalance());
	return "Preview";
	}
}	

@RequestMapping(value="/AgainLogin")
public String againLogin() {
		return "redirect:/HomePage.obj";
}
/*************************************Account Info***********************************************/
@RequestMapping(value="/AccountInfo")
public String accountInfo(@RequestParam("account")int account,Model model) {

	Customer cus1=service.getCustomer(account);
	model.addAttribute("name", cus1.getName());
	model.addAttribute("email", cus1.getEmailID());
	model.addAttribute("ph", cus1.getPhoneNo());
	model.addAttribute("account", cus1.getAccountNo());
	model.addAttribute("bal", cus1.getBalance());
	return "SuccessInfoPage";
	
}

@RequestMapping(value="/ToAllFunctionPage")
public String toAllFunctionPage(@RequestParam("account")int account,Model model) {
		model.addAttribute("acc", account);
	return "AllFunctionPage";
}
/*************************************Deposit***********************************************/
@RequestMapping(value="/Deposit")
public String deposit(Model model) {
	Customer cus1= new Customer();
	model.addAttribute("dep", cus1);
	return "DepositPage";
}

@RequestMapping(value="/Depositfinal")
public String depositfinal(@ModelAttribute("dep")Customer cust,Model model) {
	    
	service.deposit(acn, cust.getBalance());
	
	Customer cus1=service.getCustomer(acn);
	model.addAttribute("name", cus1.getName());
	model.addAttribute("email", cus1.getEmailID());
	model.addAttribute("ph", cus1.getPhoneNo());
	model.addAttribute("account", cus1.getAccountNo());
	model.addAttribute("bal", cus1.getBalance());
	model.addAttribute("sucMsg", "Your transaction is successful.Amount Added in Rs."+cust.getBalance());
	
	return "SuccessInfoPage";
	
}

/*************************************Withdraw***********************************************/
@RequestMapping(value="/Withdraw")
public String withdraw(Model model) {
	Customer cus1= new Customer();
	model.addAttribute("with", cus1);
	return "WithdrawPage";
}

@RequestMapping(value="/Withdrawfinal")
public String withdrawfinal(@ModelAttribute("with")Customer cust,Model model) {
	 Customer cus2=service.getCustomer(acn);
    
	if(cus2.getBalance()<cust.getBalance()) {
		model.addAttribute("aboveLimit", "Balance entered is above current balance");
		return "WithdrawPage";
	}else
	service.withdraw(acn, cust.getBalance());
	Customer cus1=service.getCustomer(acn);
	model.addAttribute("name", cus1.getName());
	model.addAttribute("email", cus1.getEmailID());
	model.addAttribute("ph", cus1.getPhoneNo());
	model.addAttribute("account", cus1.getAccountNo());
	model.addAttribute("bal", cus1.getBalance());
	model.addAttribute("sucMsg", "Your transaction is successful.Amount Debited in Rs"+cust.getBalance());
	return "SuccessInfoPage";
	
}
/*************************************Fund Transfer***********************************************/
@RequestMapping(value="/FundTransfer")
public String fundTranfer(Model model) {
	Customer cus1= new Customer();
	model.addAttribute("transfer", cus1);
	return "FundTransferPage";
}

@RequestMapping(value="/FundTransferfinal")
public String fundTranferfinal(@ModelAttribute("transfer")Customer cust,Model model) {

	 Customer cus2=service.getCustomer(acn);
	 Customer cus3=service.getCustomer(cust.getAccountNo());   
		if(cus2.getBalance()<cust.getBalance()) {
			model.addAttribute("aboveLimit", "Balance entered is above current balance");
			return "FundTransferPage";
		}else if(cus3==null){
			model.addAttribute("error", "This Account does not exists ");
			return "FundTransferPage";
		}else
			
	service.withdraw(acn, cust.getBalance());
	service.deposit(cust.getAccountNo() , cust.getBalance());
	Customer cus1=service.getCustomer(acn);
	model.addAttribute("name", cus1.getName());
	model.addAttribute("email", cus1.getEmailID());
	model.addAttribute("ph", cus1.getPhoneNo());
	model.addAttribute("account", cus1.getAccountNo());
	model.addAttribute("bal", cus1.getBalance());
	model.addAttribute("sucMsg", "Your transaction is successful.Amount transferred in Rs"+cust.getBalance());
	return "SuccessInfoPage";
	
}
/****************************************Print Transaction**********************************************************************/
@RequestMapping(value="/PrintTransac")
public String transactionHistory(@RequestParam("account")int acc,Model model) {
	ArrayList<Transaction>traList =service.transactionHistory(acc);
	model.addAttribute("tList", traList);
return "PrintTransaction";
}



}
