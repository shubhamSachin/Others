package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;


public interface WalletService {
    
public Customer getCustomer(int id) ;
	
	public Customer createAccount(Customer cus) ;
	
	public Customer deposit(int accNo,int b);
	
	public Customer withdraw(int accNo,int b);
	
	public Transaction getDetail(int id) ;
	
	public ArrayList<Transaction> transactionHistory(int acc) ;
}
