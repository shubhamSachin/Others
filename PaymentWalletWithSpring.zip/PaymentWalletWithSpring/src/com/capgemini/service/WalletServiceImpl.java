package com.capgemini.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.DAO.WalletDAO;
import com.capgemini.DAO.WalletDAOImpl;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;



@Service
public class WalletServiceImpl implements WalletService{
	
	@Autowired
	WalletDAO dao=null;
	
	public WalletDAO getDao() {
		return dao;
	}
	public void setDao(WalletDAO dao) {
		this.dao = dao;
	}
	
	
	
	/*******************************************************************/
	public Customer createAccount(Customer cus)  {
		
		return dao.createAccount(cus);
	}
	
	/*******************************************************************/
	public Customer deposit(int accNo, int balT)  {
		Customer cus=dao.getCustomer(accNo);
		int money=cus.getBalance()+balT;
		return dao.deposit(accNo,money,balT);
	}
	
	/*******************************************************************/
	public Customer withdraw(int accNo, int b)  {
		Customer cus=dao.getCustomer(accNo);
		System.out.println(cus);
		int money=cus.getBalance()-b;
		return dao.withdraw(accNo, money,b);
	}
	
	/*******************************************************************/
	public Transaction getDetail(int id)  {
		
		return dao.getDetail(id);
	}
	/*******************************************************************/
	@Override
	public ArrayList<Transaction> transactionHistory(int acc)  {
		
		return dao.transactionHistory(acc);
	}
	/*******************************************************************/
	@Override
	public Customer getCustomer(int id) {
		return dao.getCustomer(id);
	}
	
	
	
	
	
	
}
