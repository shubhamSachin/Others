package com.capgemini.bean;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Customer")
public class Customer {
	@NotEmpty(message="userName is mandatory")
	@Size(min=3,message="UserName should be of minimum 3 characters")
	@Column(name="name",length=20)
	private  String name;
	
	@Id
	@Column(name="account_no",length=10)
	private  int accountNo;
	
	@NotEmpty(message="phoneNo is mandatory")
	@Pattern(regexp="[789]{1}[0-9]{9}",message="Phone no should be of 10 digits starting with 7,8 or 9")
	@Column(name="phoneNo",length=10)
	private  String phoneNo;
	
	@Column(name="balance",length=10)
    private  int balance;
	
	@NotEmpty(message="emailId is mandatory")
	@Pattern(regexp="^[A-Za-z0-9+_.-]+@(.+)$",message="Email id should be of correct format")
	@Size(max=25,message="Max 25 charcters")
	@Column(name="email",length=25)
    private  String emailID;
	
	@NotEmpty(message="Password is mandatory")
	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$",
	message="Password should contain atleast one upperCase,one LowerCase,one Number and one Special Charcters and minimum of 8 characters")
	@Size(max=19,message="Max 19 charcters")
	@Column(name="password",length=19)
    private   String password;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public Customer() {
		super();
		
	}
	public Customer(String name, int accountNo, String phoneNo, int balance, String emailID, String password) {
		super();
		this.name = name;
		this.accountNo = accountNo;
		this.phoneNo = phoneNo;
		this.balance = balance;
		this.emailID = emailID;
		this.password = password;
	
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", accountNo=" + accountNo + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", emailID=" + emailID + ", password=" + password + "]";
	}
	
	
    
}
