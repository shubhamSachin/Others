package com.capgemini.bean;

import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {
	
	@Id
	@Column(name="transac_id")
	private int transacId ;
	
	@Column(name="account")
	private int accountNo;
	
	@Column(name="amount")
	private int amount;

	@Column(name="transac_date")
	private Date date;
	
	@Column(name="transac_type")
	private String transactionType;
	
	public int getTransacId() {
		return transacId;
	}
	public void setTransacId(int transacId) {
		this.transacId = transacId;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	@Override
	public String toString() {
		return "Transaction [transacId=" + transacId + ", accountNo=" + accountNo + ", amount=" + amount + ", date="
				+ date + ", transactionType=" + transactionType + "]";
	}
	
	public Transaction(int transacId, int accountNo, int amount, Date date, String transactionType) {
		super();
		this.transacId = transacId;
		this.accountNo = accountNo;
		this.amount = amount;
		this.date = date;
		this.transactionType = transactionType;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

}
