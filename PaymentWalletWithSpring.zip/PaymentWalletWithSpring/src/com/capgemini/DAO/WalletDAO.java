package com.capgemini.DAO;


import java.util.ArrayList;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;


public interface WalletDAO {
	  public Customer getCustomer(int id) ;
		public Customer createAccount(Customer cus) ;
		public Customer deposit(int accNo,int TotalBalance,int balT);
		public Customer withdraw(int accNo,int TotalBal,int balT);
		public void addDetail(String type,int amount,int accountl) ;
		public Transaction getDetail(int id) ;
		public ArrayList<Transaction> transactionHistory(int acc) ;
}
