package com.capgemini.DAO;




import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;



@Repository
@Transactional
public class WalletDAOImpl implements WalletDAO{
	
	@PersistenceContext
	EntityManager em=null;
	
	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}
	

	Customer cus = new Customer();
     Transaction transac=new Transaction();
	
     public Customer getCustomer(int id)  {
 		cus=em.find(Customer.class, id);
      	return cus;
 	}
 	
 	public Customer deposit(int accNo, int TotalBal,int balT)  {
 	  String type="Credit";
 		cus=em.find(Customer.class,  accNo);
 	   cus.setBalance(TotalBal);
 	   
 	   em.merge(cus);
 	   
 	   System.out.println("Transaction Succesful");
 	   
 	   addDetail(type, balT, accNo);
 		return cus;
 	}
 	
 	public Customer withdraw(int accNo, int TotalBal,int balT)  {
 		 String type="Debit";
 		cus=em.find(Customer.class,  accNo);
 		   cus.setBalance(TotalBal);
 		   
 		   em.merge(cus);
 		   
 		   System.out.println("Transaction Succesful");
 			
 		   addDetail(type, balT, accNo);
 		   return cus;
 		
 	}

 		
 	
 	public Customer createAccount(Customer cus)  {
 		
 		em.persist(cus);
 		
 		System.out.println("Data inserted");
 	return cus;
 	}



 	public void addDetail(String type,int amount,int account)  {
 		Transaction transac1= new Transaction();
 		Random rand = new Random(); 
 		int a = rand.nextInt(9000000)+1000000;
 		transac1.setAccountNo(account);
 		transac1.setTransacId(a);
 		transac1.setAmount(amount);
 		transac1.setDate(Date.valueOf(LocalDate.now()));
 		transac1.setTransactionType(type);
 		
 		
 		
 		em.persist(transac1);
 		
 		System.out.println("Data inserted");
 		System.out.println("Your transaction Id associated with this transaction is :"+a);
 	}

 	public Transaction getDetail(int id)  {
 		transac=em.find(Transaction.class, id);
         return transac;
 	}

 	@Override
 	public ArrayList<Transaction> transactionHistory(int acc)  {
 		String qry="Select cus from Transaction cus where cus.accountNo=:acc";
 	
 		
 		TypedQuery<Transaction>tq=em.createQuery(qry,Transaction.class);
 		tq.setParameter("acc", acc);
        
 		//int count=1;
 		ArrayList<Transaction> tList=(ArrayList<Transaction>) tq.getResultList();
// 		for (Transaction transaction : tList) {
// 			System.out.println( count+". \tTransaction ID: "+transaction.getTransacId()+". \tAccountNo: "+transaction.getAccountNo()+". \tAmount in Rs.: "+transaction.getAmount()+". \tDate: "+transaction.getDate()+". \tTransaction Type: "+transaction.getTransactionType());
// 			count++;
// 		}
 		
 		return tList;
 	}

}
