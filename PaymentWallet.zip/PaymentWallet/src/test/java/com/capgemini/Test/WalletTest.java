package com.capgemini.Test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.DAO.WalletDAO;
import com.capgemini.DAO.WalletDAOImpl;
import com.capgemini.exception.WalletException;
import com.capgemini.service.WalletValidator;

public class WalletTest {
	WalletValidator valid = new WalletValidator();
	@Test
	public void testMethod1() {
		
		String phone = "7036945166";
		boolean actual = valid.validatePhoneNo(phone);
		boolean expected = true;
		
		assertEquals(expected,actual);			
	}
	
	@Test
	public void testMethod2() {
		
		String phone = "6036945166";
		boolean actual = valid.validatePhoneNo(phone);
		boolean expected = false;
		
		assertEquals(expected,actual);			
	}
	
	
	@Test
	public void testMethod4() {
		
		String email = "shubham.sachin001@gmail.com";
		boolean actual = valid.validateEmail(email);
		boolean expected = true;
		
		assertEquals(expected,actual);			
	}
	
	@Test
    public void testMethod5() {
		
		String email = "shubhamgmail.com";
		boolean actual = valid.validateEmail(email);
		boolean expected = false;
		
		assertEquals(expected,actual);			
	}
	
	@Test
    public void testMethod6() {
		
		String password = "Hello123";
		boolean actual = valid.validatePassword(password);
		boolean expected = false;
		
		assertEquals(expected,actual);			
	}
	
	@Test
    public void testMethod7() {
		
		String password = "Hello@123";
		boolean actual = valid.validatePassword(password);
		boolean expected = true;
		
		assertEquals(expected,actual);			
	}
	
	@Test(expected=NullPointerException.class)
    public void testMethod8() {
		WalletDAO dao = new WalletDAOImpl();
		
		try {
			dao.createAccount(null);
		} catch (WalletException e) {
			System.out.println(e.getMessage());
		}
		
				
	}
}





















