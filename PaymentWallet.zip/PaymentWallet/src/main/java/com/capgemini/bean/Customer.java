package com.capgemini.bean;

public class Customer {
	private  String name;
	private  int accountNo;
	private  String phoneNo;
    private  int balance;
    private  String emailID;
    private   String password;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", accountNo=" + accountNo + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", emailID=" + emailID + "]";
	}
    public Customer() {
    	
    }
    public Customer(String name, int accountNo,String phoneNo,int balance,String emailId,String password) {
    	super();
    	this.name = name;
    	this.accountNo = accountNo;
    	this.phoneNo=phoneNo;
    	this.balance=balance;
    	this.emailID=emailId;
    	this.password = password;
    }
}
