package com.capgemini.exception;

public class WalletException extends Exception {
	
public WalletException() {
	
}
public WalletException(String s) {
	super(s);
}
}
