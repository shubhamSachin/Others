package com.capgemini.ui;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.WalletException;
import com.capgemini.service.*;



public class Main {

	public static void main(String[] args) {
		String accNo;
		Scanner sc = new Scanner(System.in);
		WalletValidator validate = new WalletValidator(); 
         WalletService service = new WalletServiceImpl();
         Transaction transac = new Transaction();
         int option;
         do {
         Customer cus = new Customer();
         System.out.println("Enter your option");
         System.out.println("1.Account Details \n2.Create Account \n3.Deposit \n4.Withdraw \n5.Fund Transfer \n6.Print Transaction \n7.Exit ");
         option = sc.nextInt();
         
         switch(option) {
         case 1:
        	 try {
        	
        	
        	System.out.println("Enter Account No.");
        	String accountNo = sc.next();      	

    		System.out.println("Enter your password");
    		String password = sc.next();
    		
        	
		   cus = service.getCustomer(Integer.parseInt(accountNo));
		   
		   if(service.checkAccount(Integer.parseInt(accountNo))==null)
		   {
			   throw new WalletException("Account does not exists");
			   
		   }

		    if (password.equals(cus.getPassword())==false) {
			   throw new WalletException("Password Incorrect");
		    }
        	System.out.println("Name : "+cus.getName());  
        	System.out.println("Phone No. : "+cus.getPhoneNo());
        	System.out.println("Email ID : "+cus.getEmailID());
        	System.out.println("Balance : "+cus.getBalance());
        	System.out.println("Wallet Account No :"+cus.getAccountNo());
        	 System.out.println("*****************************************************");
        	 System.out.println("*****************************************************");
        	 }catch(NumberFormatException e) {
        		 System.out.println("Account no.value Should be of numeric value"); 
        	 }
        	 
        	 catch(WalletException e2){
        		 System.out.println(e2.getMessage()); 
        	 }
        	break;
        	
         case 2:
        	 try {
        	 System.out.println("Enter Name ");
        	 String name = sc.next();
        	 
        	 System.out.println("Enter Phone No ");
        	 String phone = sc.next();
        	 if(validate.validatePhoneNo(phone) ==false)
      			throw new WalletException("Invalid Phone Number");
        	 
        	 System.out.println("Enter Email ID ");
        	 String email = sc.next();
        	 if(validate.validateEmail(email) ==false)
       			throw new WalletException("Invalid Email format");

             
        	 
        	 System.out.println("Generate Password \n(Password should be of min 8 charcaters and must contain atleast one upper case ,one lower case,one number and a special character. )");
        	 String password = sc.next();
        	 if(validate.validatePassword(password)==false)
       			throw new WalletException("Invalid Password");
        	 
        	 System.out.println("Account generated");
        	 Random rand = new Random();
        	 int a = rand.nextInt(90000)+10000;
        	 System.out.println("Your new Digital Wallet Account No. is : "+a);
        	 System.out.println("*****************************************************");
        	 System.out.println("*****************************************************");
        	 cus.setName(name);
        	 cus.setPhoneNo(phone);
        	 cus.setEmailID(email);
        	 cus.setAccountNo(a);
        	 cus.setPassword(password);
        	 cus = service.createAccount(cus);
        	 }
        	 catch(WalletException e){
        		 System.out.println(e.getMessage()); 
        	 }
        	 
        	 break;
         case 3:
        	 try {
		 
        	 System.out.println("Add Money");
        	 System.out.println();
        	 System.out.println("Enter Your Account No.");
        	 accNo = sc.next();
        	 if(service.checkAccount(Integer.parseInt(accNo))==null)
  		   {
  			   throw new WalletException("Account does not exists");
  			   
  		   }
        	 
        	 
        	 System.out.println("Enter the amount which you want to deposit : ");
        	 String b = sc.next();
        
        	 cus = service.deposit(Integer.parseInt(accNo), Integer.parseInt(b));
        	 System.out.println("Enter Password");
        	 String password = sc.next();
        	 if (password.equals(cus.getPassword())==false)
  			   throw new WalletException("Password Incorrect");
        	 
        	 System.out.println("Your new Wallet balance is "+cus.getBalance());
        	 
        	 
        	 Random rand = new Random();
        	 int a = rand.nextInt(9000000)+1000000;
        	 transac.setAccountNo(Integer.parseInt(accNo));
        	 transac.setTransacId(a);
        	 transac.setAmount(Integer.parseInt(b));
        	 transac.setDate(LocalDate.now());
        	// transac.setTime(LocalDate.now(clock));
        	 
        	 transac.setTransactionType("Deposit");
        	 transac = service.addDetail(transac);
        	 System.out.println("Your transaction Id associated with this transaction is :"+a);
        	 
        	 
        	 System.out.println("*****************************************************");
        	 System.out.println("*****************************************************");
        	 }catch(NumberFormatException e) {
        		 System.out.println("Account no.value Should be of numeric value"); 
        	 }
        	 catch(WalletException e) {
        		 System.out.println(e.getMessage());
        	 }
        	 break;	 
         case 4:
        	 try {
            	 System.out.println("Withdraw");
            	 System.out.println();
            	 System.out.println("Enter Your Account No.");
            	 accNo = sc.next();
            	
            	 if(service.checkAccount(Integer.parseInt(accNo))==null)
        		   {
        			   throw new WalletException("Account does not exists");
        			   
        		   }
            	 
            	 Customer cus1 = service.getCustomer(Integer.parseInt(accNo));
            	 System.out.println("Enter the amount which you want to Withdraw : ");
            	 String b = sc.next();
            	   if((cus1.getBalance()<Integer.parseInt(b))==true)
                	   throw new WalletException("Amount entered is greater than your available balance");
                 	 
            	 
            	 
            	 cus = service.withdraw(Integer.parseInt(accNo), Integer.parseInt(b));
            	 System.out.println("Enter Password");
            	 String password = sc.next();
            	 if (password.equals(cus.getPassword())==false)
      			   throw new WalletException("Password Incorrect");
            	 
            	 System.out.println("Your new Wallet balance is "+cus.getBalance());
            	 System.out.println("*****************************************************");
            	 System.out.println("*****************************************************");
            	 
            	 Random rand = new Random();
            	 int a = rand.nextInt(9000000)+1000000;
            	 transac.setAccountNo(Integer.parseInt(accNo));
            	 transac.setTransacId(a);
            	 transac.setAmount(Integer.parseInt(b));
            	 transac.setDate(LocalDate.now());
            	// transac.setTime(LocalDate.now(clock));
            	 transac.setTransactionType("Withdraw");
            	 transac = service.addDetail(transac);
            	 System.out.println("Your transaction Id associated with this transaction is :"+a);
            	 
            	 }catch(NumberFormatException e) {
            		 System.out.println("Account no.value Should be of numeric value"); 
            	 }
            	 catch(WalletException e) {
            		 System.out.println(e.getMessage());
            	 }
        	 break;	
         case 5:
        	 try {
            	 System.out.println("Fund Transfer");
            	 System.out.println();
            	 System.out.println("Enter Your Account No.");
            	 accNo = sc.next();
            	
            	 if(service.checkAccount(Integer.parseInt(accNo))==null)
        		   {
        			   throw new WalletException("Account does not exists");
        			   
        		   }
            	 
            	 System.out.println("Enter reciever Account No.");
            	String accNo1 = sc.next();
            	
            	if(service.checkAccount(Integer.parseInt(accNo1))==null)
       		   {
       			   throw new WalletException("Account does not exists");
       			   
       		   }
            	
            	 Customer cus1 = service.getCustomer(Integer.parseInt(accNo));
            	 System.out.println("Enter the amount which you want to transfer : ");
            	 String b = sc.next();
            	   if((cus1.getBalance()<Integer.parseInt(b))==true)
                	   throw new WalletException("Amount entered is greater than your available balance");
                 	 
            	 
            	 cus = service.fundTransfer(Integer.parseInt(accNo),Integer.parseInt(accNo1), Integer.parseInt(b));
            	
            	 System.out.println("Enter Password");
            	 String password = sc.next();
            	 if (password.equals(cus.getPassword())==false)
      			   throw new WalletException("Password Incorrect");
            	 
            	 System.out.println("Your new Wallet balance is "+cus.getBalance());
            	 System.out.println("*****************************************************");
            	 System.out.println("*****************************************************");
            	 
            	 Random rand = new Random();
            	 int a = rand.nextInt(9000000)+1000000;
            	 transac.setAccountNo(Integer.parseInt(accNo));
            	 transac.setTransacId(a);
            	 transac.setAmount(Integer.parseInt(b));
            	 transac.setDate(LocalDate.now());
            	// transac.setTime(LocalDate.now(clock));
            	 
            	 transac.setTransactionType("Deposit");
            	 transac = service.addDetail(transac);
            	 System.out.println("Your transaction Id associated with this transaction is :"+a);
            	 
            	 }
            	 catch(WalletException e) {
            		 System.out.println(e.getMessage());
            	 }
        	 break;	
        	 
         case 6:
        	 System.out.println("Print Transaction");
             System.out.println("Enter Transactuion Id");
             String b = sc.next();
             
             try {
				transac = service.getDetail(Integer.parseInt(b));
				System.out.println("Account No: "+transac.getAccountNo());
				System.out.println("Amount No: "+transac.getAmount());
				System.out.println("Date :"+transac.getDate());
				System.out.println("transaction Type: "+transac.getTransactionType());
				System.out.println("*****************************");
			} catch (NumberFormatException e) {
			
				e.printStackTrace();
			} catch (WalletException e) {
			
				System.out.println(e.getMessage());
			}
        	 
        	 
        	 break;
        	  
         case 7:
     		System.exit(0);
         }
     }while(option!= 7);
	}      
}    		
         