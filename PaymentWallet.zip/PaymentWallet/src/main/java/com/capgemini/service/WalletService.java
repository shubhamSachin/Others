package com.capgemini.service;


import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.WalletException;

public interface WalletService {
    
	public Customer getCustomer(int id) throws WalletException;
	public Customer createAccount(Customer cus) throws WalletException;
	public Customer deposit(int accNo,int b)throws WalletException;
	public Customer withdraw(int accNo,int b)throws WalletException;
	public Customer fundTransfer(int accNo1,int accNo2,int b)throws WalletException;
	public Customer checkAccount(int k);
	public Transaction addDetail(Transaction transac) throws WalletException;
	public Transaction getDetail(int id) throws WalletException;
}
