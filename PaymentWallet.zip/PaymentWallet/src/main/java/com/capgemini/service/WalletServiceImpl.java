package com.capgemini.service;


import com.capgemini.DAO.WalletDAO;
import com.capgemini.DAO.WalletDAOImpl;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.WalletException;



public class WalletServiceImpl implements WalletService{
	
	WalletDAO dao;
	public WalletServiceImpl() {
		dao = new WalletDAOImpl();
	}
	public Customer getCustomer(int id) throws WalletException {
		return dao.getCustomer(id);
	}
	public Customer createAccount(Customer cus) throws WalletException {
		
		return dao.createAccount(cus);
	}
	public Customer deposit(int accNo, int b) throws WalletException {
		
		return dao.deposit(accNo, b);
	}
	public Customer withdraw(int accNo, int b) throws WalletException {
		
		return dao.withdraw(accNo, b);
	}
	public Customer fundTransfer(int accNo1, int accNo2, int b) throws WalletException {
		
		return dao.fundTransfer(accNo1, accNo2, b);
	}
	public Customer checkAccount(int k) {
		// TODO Auto-generated method stub
		return dao.checkAccount(k);
	}
	public Transaction addDetail(Transaction transac) throws WalletException {
		// TODO Auto-generated method stub
		return dao.addDetail(transac);
	}
	public Transaction getDetail(int id) throws WalletException {
		// TODO Auto-generated method stub
		return dao.getDetail(id);
	}
	
	

}
