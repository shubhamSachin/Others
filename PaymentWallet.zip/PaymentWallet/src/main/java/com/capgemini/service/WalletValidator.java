package com.capgemini.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WalletValidator {
//     public boolean validateAccountNo(String id) {
//    			if(id==null)
//    				throw new NullPointerException();
//    			Pattern pat=Pattern.compile("^[0-9]{5}$");
//    			Matcher mat= pat.matcher(id);
//    			if(mat.matches())
//    				return true;
//    			else
//    				return false;
//    		}
     
     public boolean validatePhoneNo(String id) {
			if(id==null)
				throw new NullPointerException();
			Pattern pat=Pattern.compile("[789]{1}[0-9]{9}");
			Matcher mat= pat.matcher(id);
			if(mat.matches())
				return true;
			else
				return false;
		}
     
     public boolean validateEmail(String id) {
			if(id==null)
				throw new NullPointerException();
			Pattern pat=Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
			Matcher mat= pat.matcher(id);
			if(mat.matches())
				return true;
			else
				return false;
		}
    
     public boolean validatePassword(String id) {
			if(id==null)
				throw new NullPointerException();
			Pattern pat=Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$");
			Matcher mat= pat.matcher(id);
			if(mat.matches())
				return true;
			else
				return false;
		}
}
