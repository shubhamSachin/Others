package com.capgemini.DAO;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.bean.Customer;
import com.capgemini.bean.Transaction;
import com.capgemini.exception.WalletException;

public class WalletDAOImpl implements WalletDAO{
	 Map<Integer, Transaction> detail= new HashMap<Integer, Transaction>();
	 
	private static Map<Integer, Customer> customer= new HashMap<Integer, Customer>();
    static {
    	customer.put(10001, new Customer("Shubham",10001,"9905497849",30000,"shubham@gmail.com","Hello@123"));
    	customer.put(10002, new Customer("Gaurav",10002,"123456789",20000,"gaurav@gmail.com","Hello@123"));
    	customer.put(10003, new Customer("Shubradeep",10003,"123456788",40000,"shubra@gmail.com","Hello@123"));
    	customer.put(10004, new Customer("Swapnil",10004,"123456787",25000,"swapnil@gmail.com","Hello@123"));
    	customer.put(10005, new Customer("Sachin",10005,"123456786",30000,"sachin@gmail.com","Hello@123"));
    }
	public Customer getCustomer(int id) throws WalletException {
		Customer cus = customer.get(id);
		return cus;
	}
	
	public Customer deposit(int accNo, int b) throws WalletException {
		Customer cus = customer.get(accNo);
		int balance = cus.getBalance();
		int newBalance = balance+b;
		cus.setBalance(newBalance);
		return cus;
	}
	public Customer withdraw(int accNo, int b) throws WalletException {
		Customer cus = customer.get(accNo);
		int balance = cus.getBalance();
		int newBalance = balance-b;
		cus.setBalance(newBalance);
		return cus;
	}
	public Customer fundTransfer(int accNo1,int accNo2, int b) throws WalletException {
		Customer cus1 = customer.get(accNo1);
		Customer cus2 = customer.get(accNo2);
		int balance1 = cus1.getBalance();
		int balance2 = cus2.getBalance();
		cus1.setBalance(balance1-b);
		cus2.setBalance(balance2+b);
		return cus1;
		
	}
	public Customer createAccount(Customer cus) throws WalletException {
		customer.put(cus.getAccountNo(), cus);
		return cus;
	}

	public Customer checkAccount(int k) {
		// TODO Auto-generated method stub
		Customer cus = customer.get(k);
		return cus;
	}

	public Transaction addDetail(Transaction transac) throws WalletException {
		detail.put(transac.getTransacId(), transac);
		return transac;
	}

	public Transaction getDetail(int id) throws WalletException {
		Transaction transac = detail.get(id);
		return transac;
	}

	
}
